/*import {Pool} from "pg";

const pool = new Pool({
    user: "postgres",
    password: "crmadminuser",
    host: "localhost",
    //host: "crm-db-instance.cncooa6u6jo0.ap-south-1.rds.amazonaws.com",
    port: 5432,
    database: "crm_db"
})

pool.connect()
  .then(() => console.log('Connected to PostgreSQL'))
  .catch(err => console.error('Connection error', err.stack));

module.exports = pool;

export const poo = serverless(app); */